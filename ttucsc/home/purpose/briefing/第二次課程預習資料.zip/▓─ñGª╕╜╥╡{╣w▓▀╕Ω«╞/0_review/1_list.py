#!/usr/bin/env python
# -*- encoding: utf-8 -*-

empty_list = []
l1 = ['a', 'string', 1]
l2 = [1.5, l1]

print u'簡單的測試'
print l1[0]
print l1[1:-1]
print l1[::-1]
print

print u'迭代 l1'
for item in l1:
    print item
print
 
print u'利用 enumerate 枚舉 l1'   
for i, item in enumerate(l1):
    print 'l1[%s] = %s' % (i, repr(item))
print
