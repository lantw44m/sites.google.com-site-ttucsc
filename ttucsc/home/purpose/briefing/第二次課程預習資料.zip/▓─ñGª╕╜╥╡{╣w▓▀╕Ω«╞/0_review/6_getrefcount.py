#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import sys
print sys.getrefcount(1)

s = set('abcd')
a = s
b = s
c = s
print sys.getrefcount(s)

