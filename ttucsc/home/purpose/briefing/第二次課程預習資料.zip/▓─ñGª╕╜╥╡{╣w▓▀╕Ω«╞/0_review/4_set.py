#!/usr/bin/env python
# -*- encoding: utf-8 -*-

s1 = set('python')
s2 = set('programming languge')
print u'簡單的測試'
print 's1 = ', s1
print 's2 = ', s2
print 's1 & s2 = ', s1 & s2 # 交集
print 's1 | s2 = ', s1 | s2 # 聯集
print 's1 - s2 = ', s1 - s2 # 差集
print 's1 ^ s2 = ', s1 ^ s2 # 對稱差集
print

