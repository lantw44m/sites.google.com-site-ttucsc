#!/usr/bin/env python
# -*- encoding: utf-8 -*-

empty_dict = {}
d1 = dict(key='value')
d2 = { u'中文字': 'unicode',
       '中文字' : '8-bit string' }
    
print u'簡單的測試'

print d1['key']
print d2['中文字']
print d2[u'中文字']

print

print u'將 d2 合併至 d1'
d1.update(d2)

print u'迭代 d1，並印出值'
for key in d1:
    print 'd1[%s] = %s' % (repr(key), repr(d1[key]))
print
    
d3 = {'a': 1, 'b': 2, 'c': 6}

print u'迭代 d3，並印出值'
for key in d3:
    print 'd3[%s] = %s' % (repr(key), repr(d3[key]))
print

print u'用 d3.keys() 取得索引列表，再利用 sorted 排序，並印出值'
for key in sorted(d3.keys()):
    print 'd3[%s] = %s' % (repr(key), repr(d3[key]))
print
