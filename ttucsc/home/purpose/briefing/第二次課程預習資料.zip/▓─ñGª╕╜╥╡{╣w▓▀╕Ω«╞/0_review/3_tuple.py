#!/usr/bin/env python
# -*- encoding: utf-8 -*-

t = ('cpython', 'jpython', 'ironpython')
print u'tuple 是不可改變的 list'
tuple[0] = 'changeit!'
