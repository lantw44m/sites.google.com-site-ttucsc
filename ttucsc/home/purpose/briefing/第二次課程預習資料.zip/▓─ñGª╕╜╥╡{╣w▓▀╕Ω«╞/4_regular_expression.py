#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import re

# with is the context manager syntax
with open('4_regular_expression.txt') as f:
    # It just a simple example for the new to learn regex.
    # You can find the example of common regex in http://regexlib.com/
    email_pattern = re.compile('[\w\.=-]+@[\w\.-]+\.[\w]{2,3}')
    result = email_pattern.findall(f.read())
    # see http://docs.python.org/library/re.html for more
    
original_total = len(result)
result = set(result) # use set to remove the duplicate items
real_total = len(result)

print result
print 'Duplicate:', original_total-real_total
print 'Found    :', real_total
