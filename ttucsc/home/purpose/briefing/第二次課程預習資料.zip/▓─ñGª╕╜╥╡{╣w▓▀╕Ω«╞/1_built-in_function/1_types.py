#!/usr/bin/env python
# -*- encoding: utf-8 -*-

print 5 / 2
print 5.0 / 2
print float(5) / 2

str_n = raw_input(u'請輸入一個數字')
print u'轉換前', repr(str_n), type(str_n)
n = int(str_n)
print u'轉換後', repr(n), type(n)

