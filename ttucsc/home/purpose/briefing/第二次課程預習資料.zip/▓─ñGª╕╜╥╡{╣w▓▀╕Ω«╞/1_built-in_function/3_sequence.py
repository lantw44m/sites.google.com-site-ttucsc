#!/usr/bin/env python
# -*- encoding: utf-8 -*-

print 'range(10) =', range(10)
print 'range(1, 10) =', range(1, 10)
print 'range(1, 10, 2) =', range(1, 10, 2)

print

print 'sum(range(1, 10)) =', sum(range(1, 10))
print 'max(range(1, 10)) =', max(range(1, 10))
print 'min(range(1, 10)) =', min(range(1, 10))

print 

print 'xrange(20) =', xrange(20)

print

all_true = [True, True, True]
all_false = [False, False, False]
mixed = [False, True, False]
cases = [all_true, all_false, mixed]
funcs = [all, any]

for all_or_any in funcs:
    for case in cases:
        func_name = str(all_or_any)[-4:-1]
        print '%s(%s) = ' % (func_name, case), all_or_any(case)
        
print

for i, c in enumerate('python'):
    print i, c, ord(c), chr(65+i)
    
import random
rnums = [random.randint(1, 100) for i in xrange(10)]
sorted_rnums = sorted(rnums)
print sorted(sorted_rnums)
reversed_sorted_rnums = reversed(sorted_rnums)
print reversed_sorted_rnums
print list(reversed_sorted_rnums)
print

for a, b in zip('apple', 'orange'):
    print a, b
