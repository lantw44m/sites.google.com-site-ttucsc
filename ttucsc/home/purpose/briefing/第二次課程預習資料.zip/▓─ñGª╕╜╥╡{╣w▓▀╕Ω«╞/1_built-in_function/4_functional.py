#!/usr/bin/env python
# -*- encoding: utf-8 -*-

import operator

print map(lambda x: x+1, range(10))
print map(lambda x, y: x+y, range(10), range(10))
print filter(lambda x: x>5, range(10))
print reduce(lambda x, y: x+y, range(10))
