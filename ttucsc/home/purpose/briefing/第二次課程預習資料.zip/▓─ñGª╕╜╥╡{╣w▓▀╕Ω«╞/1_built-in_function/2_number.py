#!/usr/bin/env python
# -*- encoding: utf-8 -*-

n = -1.25
print 'abs(n) =', abs(n)
print 'round(n) =', round(n)
print 'round(n, 1) =', round(n, 1)

n = 100
print 'bin(n) =', bin(n)
print 'oct(n) =', oct(n)
print 'hex(n) =', hex(n)
    
