#!/usr/bin/env python
# -*- encoding: utf-8 -*-

points = range(10)
print points
squares = [i**2 for i in range(10)]
print squares
cubes =  [i**3 for i in range(10)]
print cubes

xy = [[(x, y) for y in range(10)] for x in range(10)]
print xy[0][1]

isprimes = lambda x: not any(x % i == 0 for i in range(2, x))
print [x for x in range(100) if isprimes(x)]
