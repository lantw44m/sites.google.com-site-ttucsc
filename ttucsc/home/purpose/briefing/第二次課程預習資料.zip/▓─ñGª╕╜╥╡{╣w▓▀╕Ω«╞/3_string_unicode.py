#!/usr/bin/env python
# -*- encoding: utf-8 -*-

# % http://docs.python.org/release/2.7.1/library/stdtypes.html#string-formatting
    
print '%10.1f' % 100.25

# formating http://docs.python.org/release/2.7.1/library/string.html#formatspec

print '{0:>10}'.format(u'向右靠齊')

# string & unicode

s = '世界你好'
u = u'世界你好'

print s, len(s)
print u, len(u)

print repr(u.encode('utf-8')), ' = ', repr(s)
print repr(u), ' = ', repr(s.decode('utf-8'))

u = unicode(s, 'utf-8')
print u


