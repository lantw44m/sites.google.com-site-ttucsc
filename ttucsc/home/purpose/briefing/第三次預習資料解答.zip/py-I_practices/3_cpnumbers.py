#!/usr/bin/env python
# -*- encoding: utf-8 -*-

u'''請撰寫一個程式，接受不定量的手機號碼輸入，再判斷哪些手機號碼是正確的。'''

import re

CPN_PATTERN = re.compile('09[0-9]{8}')

def check(cpnumber):
    return CPN_PATTERN.match(cpnumber)

if __name__ == '__main__':

    print u'請輸入手機號碼(以空行結束)：'
    
    cpnumbers = []
    while True:
        s = raw_input()
        if not s: break
        cpnumbers.append(s)
    
    print u'以下為正確的手機號碼：'
    
    for cpnumber in cpnumbers:
        if check(cpnumber):
            print cpnumber
    

