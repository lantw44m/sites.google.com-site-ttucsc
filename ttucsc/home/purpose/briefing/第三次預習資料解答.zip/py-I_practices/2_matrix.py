#!/usr/bin/env python
# -*- encoding: utf-8 -*-

u'''請利用 comprehension，分別寫出可以相加、相減矩陣的函數'''

import operator
from functools import partial

def oper(op, A, B):
    '''接受一個函數，並使用該函數與 comprehension 處理矩陣'''
    return [
        [op(a, b) for a, b in zip(A_row, B_row)]
        for A_row, B_row in zip(A, B)
    ]

add = partial(oper, operator.add)
sub = partial(oper, operator.sub)
    
def get_matrix():
    m = []
    while True:
        s = raw_input()
        if not s: break
        m.append(map(int, s.split()))
    return m

def display_matrix(m):
    for row in m:
        print ' '.join(map(str, row))

if __name__ == '__main__':

    commands = {'a': add,
                's': sub }
                
    print u'請輸入第一個矩陣 (以空行結束)：'
    A = get_matrix()
    
    print u'請輸入第二個矩陣 (以空行結束)：'
    B = get_matrix()
    
    while True:
        try:
            display_matrix(
                commands[raw_input('要相加 (a) 或相減 (s) 這兩個矩陣？')](A, B)
            )
            print
        except KeyError:
            print u'掰掰。'
            break
