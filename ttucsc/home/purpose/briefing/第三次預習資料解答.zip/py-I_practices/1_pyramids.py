#!/usr/bin/env python
# -*- encoding: utf-8 -*-

u'''接受 n 個整數數字，並印出 n 個高度為輸入數字的金字塔。不可使用 str.center。'''

def pyramids(n):
    '''印出一個高度為 n 的金字塔'''
    for i in range(1, n, 2):
        stars = '*' * i
        print '{stars:^{n}}'.format(**locals())

if __name__ == '__main__':

    numbers = map(int, raw_input('請以空白為分隔輸入數字: ').split())

    for n in numbers:
        pyramids(n)
        print
