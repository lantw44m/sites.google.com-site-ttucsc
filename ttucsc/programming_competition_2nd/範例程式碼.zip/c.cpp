#include <iostream>
#include<fstream>
#include<stdio.h>
#include<queue>
#define MAX_M 100
#define MAX_N 100
#define INF 10000000
using namespace std;
typedef pair<int,int> P;
char maze[MAX_N][MAX_M];
int d[MAX_N][MAX_M];
int M,N;
int sx,sy;
int gx,gy;
int dx[4] = {0,0,-1,1};
int dy[4] = {1,-1,0,0};
int bfs();
void showBoard();

int bfs() {
	queue<P> que;
	for(int i=0;i<N;i++){
		for(int j=0;j<M;j++){
			d[i][j] = INF;
		}
	}
	que.push(P(sx,sy));
	d[sx][sy] = 0;
	while(que.size()){
		P t = que.front();
		que.pop();
		if(t.first == gx && t.second == gy){
			break;
		}
		for(int i=0;i<4;i++){
			int nx = t.first + dx[i];
			int ny = t.second + dy[i];
			if(nx>=0 && ny >=0 && nx<N && ny<M &&maze[nx][ny]!='#' && d[nx][ny] == INF){
				que.push(P(nx,ny));
				d[nx][ny] = d[t.first][t.second]+1;
			}
		}
	}
	return d[gx][gy];
}
//void showBoard(){
//    int r,c;
//    for(r=0;r<N;r++){
//        for(c=0;c<M;c++){
//            if(maze[r][c] == '#' || maze[r][c] == 'S' || maze[r][c] == 'G' ){
//                cout<<maze[r][c]<<' ';
//            }
//            else{
//                if(d[r][c] == INF){
//                    cout<<" .";
//                }
//                else if(d[r][c]>=10){
//                    cout<<d[r][c];
//                }
//                else{
//                    cout<<d[r][c]<<' ';
//                }
//            }
//        }
//        cout<<endl;
//    }
//    cout<<endl<<endl;
//}


int main (int argc, const char * argv[])
{
	int r,c;
	ifstream fin("pc.in");
	while(fin>>N>>M){
		/*cin >> N >> M;*/
		for(r=0;r<N;r++){
			for(c=0;c<N;c++){
				fin>>maze[r][c];
				/*cin>>maze[r][c];*/
				if(maze[r][c] == 'S' || maze[r][c] == 's' ){
					sx = r;
					sy = c;
				} else if (maze[r][c] == 'G' ||maze[r][c] == 'g' ){
					gx = r;
					gy = c;
				}
			}
		}
		/*cout<<sx<<' '<<sy<<endl;
		cout<<gx<<' '<<gy<<endl;
		showBoard();*/
		int a = bfs();
		/*showBoard();*/
		cout << a << endl;
	}
	//system("pause");
	return 0;
}

