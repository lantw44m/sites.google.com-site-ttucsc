#include<stdio.h>
#include<stdlib.h>

int main(){
	
	FILE *in;
	int num, i;
	double high, coef, sum;

	in = fopen("pf.in", "r");
	fscanf(in, " %d", &num);
	
	for(i = 0; i < num; i++){
		sum = 0;
		fscanf(in, " %lf %lf", &high, &coef);

		sum += high;
		high *= coef;
		for( ; high > 1.0; high *= coef){
			sum += high * 2;
		}

		printf("%.2f\n", sum);
	}
}
