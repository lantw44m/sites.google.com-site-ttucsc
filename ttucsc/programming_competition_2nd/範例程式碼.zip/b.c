#include<stdio.h>
int A[1000000] = {0,1,2,3};
int main(){
	FILE *in;
	int n;
	int i;
	in = fopen("pc.in", "r");
	for(i=4;i<1000000;i++)A[i]=0;
	while(fscanf(in,"%d",&n)!=EOF){
		for(i=1;i<=n;i++){
			if(A[i]!=0)continue;
			A[i] = (A[i-1]+2*A[i-2]+3*A[i-3])%65535;
		}
		printf("%d\n",A[n]);
	}
	return 0;
}
