#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void creatPlayfair( char ary[][5] , char *key );
void printAns( char ary[][5] , char ch1 , char ch2 );

void creatPlayfair( char ary[][5] , char *key )
{
	int len , i , x , y , used[26];
	
	for( i = 0 ; i < 26 ; i++ )
		used[i] = 0;
	
	len = strlen(key);
	
	for( i = x = y = 0 ; i < len ; i++ )
	{
		if( key[i] == ' ' || key[i] == '\n' )
			continue;
			
		if( !used[ key[i] - 'a' ] )
		{
			if( key[i] == 'i' || key[i] == 'j' )
			{
				used[ 'i' - 'a' ] = used[ 'j' - 'a' ] = 1;
				ary[x][y] = 'i';
			}
			else
			{
				used[ key[i] - 'a' ] = 1;
				ary[x][y] = key[i];
			}
			
			y++;
			if( y == 5 )
			{
				x++;
				y = 0;
			}
		}
	}
	
	for( i = 0 ; i < 26 ; i++ )
	{
		if( i == 'j' - 'a' )
			continue;
		if( !used[i] )
		{
			ary[x][y] = i + 'a';
			y++;
			if( y == 5 )
			{
				x++;
				y = 0;
			}
		}
		
		if( x == 5 && y == 5 )
			break;
	}
}

void printAns( char ary[][5] , char ch1 , char ch2 )
{
	int x1 , x2 , y1 , y2 , tmp , c1 , c2 , check;
	
	for( x1 = 0 ; x1 < 5 ; x1++ )
	{
		for( y1 = check = 0 ; y1 < 5 ; y1++ )
		{
			if( ary[x1][y1] == ch1 )
			{
				check = 1;
				break;
			}
		}
		if(check)
			break;
	}
	
	for( x2 = 0 ; x2 < 5 ; x2++ )
	{
		for( y2 = check = 0 ; y2 < 5 ; y2++ )
		{
			if( ary[x2][y2] == ch2 )
			{
				check = 1;
				break;
			}
		}
		if(check)
			break;
	}
						
	if( y1 == y2 )
	{
		x1++;
		x2++;
		if( x1 == 5 )
			x1 = 0;
		if( x2 == 5 )
			x2 = 0;
			
		printf( "%c%c" , ary[x1][y1] , ary[x2][y2] );
	}
	else if( x1 == x2 )
	{
		y1++;
		y2++;
		if( y1 == 5 )
			y1 = 0;
		if( y2 == 5 )
			y2 = 0;
			
		printf( "%c%c" , ary[x1][y1] , ary[x2][y2] );
	}
	else
	{
		tmp = y1;
		y1 = y2;
		y2 = tmp;
		
		printf( "%c%c" , ary[x1][y1] , ary[x2][y2] );
	}
}

int main()
{
	FILE *fin;
	
	fin = fopen( "pe.in" , "r" );
	
	char ary[5][5] , key[102] , word[102] , newword[200];
	int lw , i , n , x , k;
	
	fscanf( fin , "%d " , &x );
	
	for( k = 0 ; k < x ; k++ )
	{
		fgets( key , 102 , fin);
		fgets( word , 102 , fin);
		
		creatPlayfair( ary , key );
		
		lw = strlen(word);
		
		for( i = 0 ; i < lw ; i++ )
			if( word[i] == 'j' )
				word[i] = 'i';
				
		for( i = n = 0 ; i < lw ; n++ )
		{
			if( word[i] == ' ' || word[i] == '\n' )
			{
				i++;
				n--;
				continue;
			}
			if( n % 2 == 0 )
			{
				newword[n] = word[i];
				i++;
			}
			else
			{
				if( newword[ n - 1 ] == word[i] )
					newword[n] = 'x';
				else
				{
					newword[n] = word[i];
					i++;
				}
			}
		}
		if( n % 2 )
		{
			newword[n] = 'x';
			n++;
		}
		
		for( i = 0 ; i < n ; i += 2 )
			printAns( ary , newword[i] , newword[ i + 1 ] );
		printf("\n");
	}
	
	system("pause");
	
	return 0;
}
