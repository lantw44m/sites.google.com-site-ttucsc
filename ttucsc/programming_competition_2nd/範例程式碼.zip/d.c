#include<stdio.h>
#include<stdlib.h>
#include<string.h>

typedef struct node{
	char *phone;
	int time;
	struct node *next;
} NODE;

int main(){
	
	FILE *in;
	char *phone;
	int time;
	NODE *head = NULL, *now, *tail, *tmp, *ans;

	in = fopen("pd.in", "r");

	for( ; ;){
		phone = malloc(sizeof(char) * 10);
		if(fscanf(in, " %s %d", phone, &time) == EOF) break;
		//printf("%s %d\n", phone, time);


		if(head == NULL){
			head = malloc(sizeof(NODE));
			tail = head;
			tail -> phone = phone;
			tail -> time = time;
			tail -> next = NULL;
		}
		else{
			now = head;
			for( ; ;){
				if(!strcmp(now -> phone, phone)){
					now -> time += time;
					phone = NULL;
					break;
				}
				now = now -> next;
				if(now == NULL) break;
			}
			if(phone != NULL){
				tmp = malloc(sizeof(NODE));
				tmp -> phone = phone;
				tmp -> time = time;
				tmp -> next = NULL;
	
				tail -> next = tmp;
				tail = tail -> next;
			}
		}
	}

	now = head;
	ans = head;
	for( ; ;){
		if(now -> time > ans -> time){
			ans = now;
		}
		now = now -> next;
		if(now == NULL) break;
	}

	printf("%s %d\n",ans -> phone, ans -> time);
	
}
